package mindtree.example.orderManagementService.service.serviceImpl;

import static org.mockito.Mockito.when;
import org.mockito.Mockito;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.client.RestTemplate;

import mindtree.example.orderManagementService.model.FoodDto;
import mindtree.example.orderManagementService.model.FoodOrder;
import mindtree.example.orderManagementService.model.PaymentDetail;
import mindtree.example.orderManagementService.repository.FoodOrderRepository;
import mindtree.example.orderManagementService.service.FoodOrderService;
import mindtree.example.orderManagementService.service.Impl.FoodOrderServiceImpl;

@ExtendWith(SpringExtension.class)
class FoodOrderServiceImplTest {

	@TestConfiguration
	static class TestConfig {
		@Bean
		public FoodOrderService employeeService() {
			return new FoodOrderServiceImpl();
		}
	}

	@Autowired
	FoodOrderService orderService;

	@MockBean
	FoodOrderRepository foodRepository;

	@MockBean
	RestTemplate restTemplate;

	@Test
	public void cancelOrderTest() throws Exception {
		FoodOrder order = getOneOrderStub("ACCEPTED");
		when(foodRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(order));
		when(foodRepository.save(order)).thenReturn(order);
		orderService.cancleFoodOrder(order.getOrderId(), "CANCEL");
	}

	@Test
	public void placeOrderTest() throws Exception {
		FoodOrder order = getOneOrderStub("ACCEPTED");
		FoodDto food = getOneFoodDtoStub(1, 100, 2);
		when(foodRepository.save(order)).thenReturn(order);
		orderService.placeFoodOrder(order, "PLACE");
	}

	@Test
	public void placeOrderTestQtyMoreThanAvailableQty() throws Exception {
		FoodOrder order = getOneOrderStub("ACCEPTED");
		order.getFoodsOrdered().get(0).setQuantity(102);
		orderService.placeFoodOrder(order, "PLACE");

	}

	@Test
	public void updateOrderTestWithQtyIncrease() throws Exception {
		FoodOrder order = getOneOrderStub("ACCEPTED");
		FoodDto food = getOneFoodDtoStub(1, 100, 2);
		when(foodRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(order));
		when(foodRepository.save(order)).thenReturn(order);
		orderService.updateFoodOrder(food, order.getOrderId(), "ADD");
	}

	@Test
	public void updateOrderTestWithQtyIncreaseInsufficientQty() throws Exception {
		FoodOrder order = getOneOrderStub("ACCEPTED");
		FoodDto food = getOneFoodDtoStub(1, 100, 102);
		when(foodRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(order));
		orderService.updateFoodOrder(food, order.getOrderId(), "ADD");

	}

	@Test
	public void updateOrderTestWithQtyDecrease() throws Exception {
		FoodOrder order = getOneOrderStub("ACCEPTED");
		FoodDto food = getOneFoodDtoStub(1, 100, 2);
		when(foodRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(order));
		when(foodRepository.save(order)).thenReturn(order);
		orderService.updateFoodOrder(food, order.getOrderId(), "REMOVE");
	}

	private FoodOrder getOneOrderStub(String orderStatus) {
		FoodOrder order = new FoodOrder();
		order.setOrderId(1);
		order.setOrderStatus(orderStatus);
		order.setTotalPrice(1000);
		order.setFoodsOrdered(getFoodOrderListStub(1, 100, 2));
		order.setPayment(getOnePaymentDetailStub("PAID", "1000", "test"));
		return order;
	}

	private PaymentDetail getOnePaymentDetailStub(String paymentStatusPaid, String amount, String name) {
		PaymentDetail payDetail = new PaymentDetail();
		payDetail.setAmount(amount);
		payDetail.setPaymentId(1);
		payDetail.setPaymentMethod("CARD");
		payDetail.setPaymentStatus(paymentStatusPaid);
		payDetail.setUserName(name);
		return payDetail;
	}

	private List<FoodDto> getFoodOrderListStub(int foodId, double price, int qty) {
		List<FoodDto> foodList = new ArrayList<>();
		FoodDto food = getOneFoodDtoStub(foodId, price, qty);
		foodList.add(food);
		return foodList;
	}

	private FoodDto getOneFoodDtoStub(int foodId, double price, int qty) {
		FoodDto food = new FoodDto();
		food.setFoodId(foodId);
		food.setId(1);
		food.setPrice(price);
		food.setQuantity(qty);
		return food;
	}

}
