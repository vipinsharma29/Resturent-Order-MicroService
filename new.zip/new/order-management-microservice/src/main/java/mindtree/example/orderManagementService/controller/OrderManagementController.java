package mindtree.example.orderManagementService.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;

import mindtree.example.orderManagementService.dto.ResponseBody;
import mindtree.example.orderManagementService.exception.OrderManagementServiceException;
import mindtree.example.orderManagementService.model.FoodDto;
import mindtree.example.orderManagementService.model.FoodOrder;
import mindtree.example.orderManagementService.service.FoodOrderService;

@RestController
@RequestMapping("/api/orders")
public class OrderManagementController {

	@Autowired
	private FoodOrderService foodOrderService;

	@PutMapping("/{updateType}/{orderId}")
	public ResponseEntity<?> updateFoodOrder(@RequestBody FoodDto food, @PathVariable int orderId,
			@PathVariable String updateType) throws OrderManagementServiceException {
		return new ResponseEntity<ResponseBody<FoodOrder>>(
				new ResponseBody<FoodOrder>(null, foodOrderService.updateFoodOrder(food, orderId, updateType)),
				HttpStatus.OK);
	}

	@GetMapping("/{requestStatus}/{orderId}")
	@HystrixCommand(fallbackMethod = "fallBackMethodOnResturantServiceFailure", commandProperties = {
			@HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "100000") })
	public ResponseEntity<?> cancelFoodOrder(@PathVariable String requestStatus, @PathVariable int orderId)
			throws OrderManagementServiceException {
		return new ResponseEntity<ResponseBody<FoodOrder>>(
				new ResponseBody<FoodOrder>(null, foodOrderService.cancleFoodOrder(orderId, requestStatus)),
				HttpStatus.OK);
	}

	@PostMapping("/{requestStatus}")
	public ResponseEntity<?> placeFoodOrder(@RequestBody FoodOrder foodOrder, @PathVariable String requestStatus)
			throws OrderManagementServiceException {
		return new ResponseEntity<ResponseBody<FoodOrder>>(
				new ResponseBody<FoodOrder>(null, foodOrderService.placeFoodOrder(foodOrder, requestStatus)),
				HttpStatus.OK);
	}

	public ResponseEntity<?> fallBackMethodOnResturantServiceFailure(@RequestBody FoodDto food,
			@PathVariable Long orderId, @PathVariable String updateType) {
		return new ResponseEntity<String>("Resturant Search Service is Taking Too Long To Respond",
				HttpStatus.FAILED_DEPENDENCY);
	}

	public ResponseEntity<?> fallBackMethodOnResturantServiceFailure(@PathVariable String requestStatus,
			@PathVariable long orderId) {
		return new ResponseEntity<String>("Resturant Search Service is Taking Too Long To Respond",
				HttpStatus.FAILED_DEPENDENCY);
	}

	public ResponseEntity<?> fallBackMethodOnResturantServiceFailure(@RequestBody FoodOrder foodOrder,
			@PathVariable String requestStatus) {
		return new ResponseEntity<String>("Resturant Search Service is Taking Too Long To Respond",
				HttpStatus.FAILED_DEPENDENCY);
	}
}
