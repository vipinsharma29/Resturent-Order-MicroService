package mindtree.example.orderManagementService.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ErrorDto {

	String errorMessage;
	Object error;

	public ErrorDto() {
	}

	public ErrorDto(String errorMessage, Object error) {
		super();
		this.errorMessage = errorMessage;
		this.error = error;
	}

}
