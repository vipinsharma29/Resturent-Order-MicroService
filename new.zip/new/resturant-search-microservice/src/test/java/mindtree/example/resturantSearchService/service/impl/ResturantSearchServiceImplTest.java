package mindtree.example.resturantSearchService.service.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import mindtree.example.resturantSearchService.exception.ResturantSearchServiceAppException;
import mindtree.example.resturantSearchService.exception.service.ResturantSearchServiceException;
import mindtree.example.resturantSearchService.model.Resturant;
import mindtree.example.resturantSearchService.repository.ResturantRepository;
import mindtree.example.resturantSearchService.service.ResturantSearchService;

@ExtendWith(SpringExtension.class)
class ResturantSearchServiceImplTest {

	@TestConfiguration
	static class TestConfig {
		@Bean
		public ResturantSearchService resturantService() {
			return new ResturantSearchServiceImpl();
		}
	}

	@Autowired
	private ResturantSearchService searchService;

	@MockBean
	private ResturantRepository resturantRepository;

	@Test
	public void findByRetsturantNAme() throws ResturantSearchServiceAppException {
		List<Resturant> resturants = getResturantsList();
		when(resturantRepository.findByResturantName(Mockito.anyString())).thenReturn(resturants);
		searchService.findByResturantName(Mockito.anyString());
	}

	@Test
	public void findByRetsturantNameTest() {
		List<Resturant> resturants = new ArrayList<>();
		when(resturantRepository.findByResturantName(Mockito.anyString())).thenReturn(resturants);

		try {
			searchService.findByResturantName("Test");
		} catch (ResturantSearchServiceException e) {
			assertEquals("No Resturant found according to search Test", e.getMessage());
		}
	}

	@Test
	public void findByRetsturantLocation() {
		List<Resturant> resturants = new ArrayList<>();
		when(resturantRepository.findByCity(Mockito.anyString())).thenReturn(resturants);

		try {
			searchService.findByCity("Gwalior");
		} catch (ResturantSearchServiceException e) {
			assertEquals("No Resturant found according to search Gwalior", e.getMessage());
		}
	}

	@Test
	public void findByBudget() throws ResturantSearchServiceAppException {
		List<Resturant> resturants = getResturantsList();
		when(resturantRepository.findByBudget(Mockito.anyDouble())).thenReturn(resturants);
		searchService.findByBudgetPerPerson(Mockito.anyDouble());
	}

	@Test
	public void findByBudgetNoResultFoundTest() {
		List<Resturant> resturants = new ArrayList<>();
		when(resturantRepository.findByBudget(Mockito.anyDouble())).thenReturn(resturants);
		try {
			searchService.findByBudgetPerPerson(1000);
		} catch (ResturantSearchServiceException e) {
			assertEquals("No Resturant found according to search 1000.0", e.getMessage());
		}
	}

	private List<Resturant> getResturantsList() {
		Resturant resturant = new Resturant();
		resturant.setBudget(100);
		resturant.setCity("Gwalior");
		resturant.setResturantId(1);
		resturant.setResturantName("Test_resturant");
		List<Resturant> resturants = new ArrayList<>();
		resturants.add(resturant);
		return resturants;
	}

}
