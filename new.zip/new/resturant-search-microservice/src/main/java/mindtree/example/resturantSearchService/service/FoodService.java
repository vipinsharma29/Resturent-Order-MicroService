package mindtree.example.resturantSearchService.service;

import org.springframework.stereotype.Service;

import mindtree.example.resturantSearchService.dto.FoodDto;

@Service
public interface FoodService {

	FoodDto getFoodById(int foodId);

	FoodDto updateFoodQuantityById(int id, int qty);
}
