package mindtree.example.resturantSearchService.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import mindtree.example.resturantSearchService.model.Resturant;

@Repository
public interface ResturantRepository extends JpaRepository<Resturant, Integer> {

	public List<Resturant> findByResturantName(String resturantName);

	public List<Resturant> findByCity(String city);

	public List<Resturant> findByBudget(double budget);
}
