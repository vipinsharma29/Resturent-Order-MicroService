package mindtree.example.resturantSearchService.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import mindtree.example.resturantSearchService.exception.service.ResturantSearchServiceException;
import mindtree.example.resturantSearchService.model.Resturant;
import mindtree.example.resturantSearchService.repository.ResturantRepository;
import mindtree.example.resturantSearchService.service.ResturantSearchService;

@Service
@SuppressWarnings("unused")
public class ResturantSearchServiceImpl implements ResturantSearchService {

	@Autowired
	private ResturantRepository resturantRepository;

	@Override
	public List<Resturant> findByResturantName(String name) throws ResturantSearchServiceException {
		List<Resturant> result = resturantRepository.findByResturantName(name);
		if (result.size() == 0) {
			throw new ResturantSearchServiceException("No Resturant found according to search " + name);
		} else
			return result;
	}

	@Override
	public List<Resturant> findByCity(String city) throws ResturantSearchServiceException {
		List<Resturant> result = resturantRepository.findByCity(city);
		if (result.size() == 0) {
			throw new ResturantSearchServiceException("No Resturant found according to search " + city);
		} else
			return result;
	}

	@Override
	public List<Resturant> findByBudgetPerPerson(double budget) throws ResturantSearchServiceException {
		List<Resturant> result = resturantRepository.findByBudget(budget);
		if (result.size() == 0) {
			throw new ResturantSearchServiceException("No Resturant found according to search " + budget);
		} else
			return result;

	}

}
