package mindtree.example.resturantSearchService.controller.handler;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import mindtree.example.resturantSearchService.exception.ResturantSearchServiceAppException;

@RestControllerAdvice
public class ResturantSearchServiceHandler {

	@ExceptionHandler(ResturantSearchServiceAppException.class)
	public ResponseEntity<?> errorHandler(Exception e) {
		mindtree.example.resturantSearchService.dto.ErrorDto errdto = new mindtree.example.resturantSearchService.dto.ErrorDto(
				e.getMessage(), e);
		mindtree.example.resturantSearchService.dto.ResponseBody<Void> response = new mindtree.example.resturantSearchService.dto.ResponseBody<>(
				errdto, null);
		return new ResponseEntity<mindtree.example.resturantSearchService.dto.ResponseBody<Void>>(response,
				HttpStatus.INTERNAL_SERVER_ERROR);
	}

}
