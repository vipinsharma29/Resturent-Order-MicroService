package mindtree.example.orderManagementService.exception.service.custom;

import mindtree.example.orderManagementService.exception.service.ManageOrderServiceException;

public class InsuffecientQuantityException extends ManageOrderServiceException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InsuffecientQuantityException() {
		super();
		
	}

	public InsuffecientQuantityException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		
	}

	public InsuffecientQuantityException(String message, Throwable cause) {
		super(message, cause);
		
	}

	public InsuffecientQuantityException(String message) {
		super(message);
		
	}

	public InsuffecientQuantityException(Throwable cause) {
		super(cause);
		
	}

	
}
