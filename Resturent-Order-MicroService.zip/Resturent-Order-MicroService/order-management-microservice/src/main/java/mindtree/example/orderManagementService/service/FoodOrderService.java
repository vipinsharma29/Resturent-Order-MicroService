package mindtree.example.orderManagementService.service;

import org.springframework.stereotype.Service;

import mindtree.example.orderManagementService.exception.service.ManageOrderServiceException;
import mindtree.example.orderManagementService.model.FoodDto;
import mindtree.example.orderManagementService.model.FoodOrder;

@Service
public interface FoodOrderService {

	FoodOrder placeFoodOrder(FoodOrder foodOrder, String requestStatus) throws ManageOrderServiceException;

	FoodOrder cancleFoodOrder(int orderId, String requestStatus) throws ManageOrderServiceException;

	FoodOrder updateFoodOrder(FoodDto food, int orderId, String updateType) throws ManageOrderServiceException;
}
