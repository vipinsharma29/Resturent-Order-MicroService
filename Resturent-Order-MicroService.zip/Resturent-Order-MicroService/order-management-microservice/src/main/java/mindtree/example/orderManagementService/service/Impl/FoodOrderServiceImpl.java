package mindtree.example.orderManagementService.service.Impl;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import mindtree.example.orderManagementService.exception.service.ManageOrderServiceException;
import mindtree.example.orderManagementService.exception.service.custom.InsuffecientQuantityException;
import mindtree.example.orderManagementService.exception.service.custom.PaymentFailedException;
import mindtree.example.orderManagementService.model.FoodDto;
import mindtree.example.orderManagementService.model.FoodOrder;
import mindtree.example.orderManagementService.model.PaymentDetail;
import mindtree.example.orderManagementService.repository.FoodOrderRepository;
import mindtree.example.orderManagementService.service.FoodOrderService;
import mindtree.example.orderManagementService.util.OrderManagementUtil;

@Service
public class FoodOrderServiceImpl implements FoodOrderService {

	@Autowired
	FoodOrderRepository foodRepository;

	@Autowired
	OrderManagementUtil util;

	@Override
	public FoodOrder placeFoodOrder(FoodOrder foodOrder, String requestStatus) throws ManageOrderServiceException {
		FoodOrder foodOrder2 = null;
		boolean updateStatus = false;
		PaymentDetail paymentDetail = null;
		List<FoodDto> list = foodOrder.getFoodsOrdered();
		List<FoodDto> foodsOrdered = list.stream().map(orderedFood -> {
			if (requestStatus.equalsIgnoreCase("PLACE")) {
				orderedFood.setQuantity(orderedFood.getQuantity() * -1);
			} else {
				orderedFood.setQuantity(orderedFood.getQuantity() * 1);
			}
			return orderedFood;
		}).collect(Collectors.toList());
		try {
			updateStatus = updateFoodQuantity(foodsOrdered, requestStatus);
			foodOrder2 = checkAndUpdatePaymentForOrder(foodOrder, foodOrder2, updateStatus, paymentDetail);
		} catch (InsuffecientQuantityException e) {
			throw new ManageOrderServiceException(e.getMessage());
		}
		return foodOrder2;

	}

	@Override
	public FoodOrder cancleFoodOrder(int orderId, String requestStatus) throws ManageOrderServiceException {
		FoodOrder food = null;
		FoodOrder result = foodRepository.findById(orderId).orElse(null);

		List<FoodDto> foodsOrdered = result.getFoodsOrdered().stream().map(orderedFood -> {
			if (requestStatus.equalsIgnoreCase("PLACE")) {
				orderedFood.setQuantity(orderedFood.getQuantity() * -1);
			} else {
				orderedFood.setQuantity(orderedFood.getQuantity() * 1);
			}
			return orderedFood;
		}).collect(Collectors.toList());

		try {
			boolean updateStatus = updateFoodQuantity(foodsOrdered, requestStatus);
			if (updateStatus) {
				result.getPayment().setPaymentStatus("REFUND");
				result.setOrderStatus("CANCELED");
				food = foodRepository.save(result);
			}
		} catch (InsuffecientQuantityException e) {
			throw new ManageOrderServiceException(e.getMessage());
		}
		return food;
	}

	@Override
	public FoodOrder updateFoodOrder(FoodDto foodDto, int orderId, String updateType)
			throws ManageOrderServiceException {
		FoodOrder result = foodRepository.findById(orderId).orElse(null);
		boolean updateStatus = false;
		List<FoodDto> updatedFoods = new ArrayList<>();

		List<FoodDto> foods = result.getFoodsOrdered();

		for (FoodDto food : foods) {
			food.setQuantity(foodDto.getQuantity());
		}

		try {
			updateStatus = checkAndUpdateUpdateFoodQuantityInDb(foodDto, updateType, updatedFoods);
			if (updateStatus) {
				updatePaymentDetails(foodDto, result, updateType);
				result = foodRepository.save(result);
			}
		} catch (InsuffecientQuantityException e) {
			throw new ManageOrderServiceException(e.getMessage());
		}
		return result;
	}

	private boolean checkAndUpdateUpdateFoodQuantityInDb(FoodDto foodDto, String updateType, List<FoodDto> updatedFoods)
			throws InsuffecientQuantityException {
		boolean updateStatus;
		if (updateType.equalsIgnoreCase("ADD")) {
			foodDto.setQuantity(foodDto.getQuantity() * -1);
			updatedFoods.add(foodDto);
			updateStatus = updateFoodQuantity(updatedFoods, updateType);
		} else {
			updatedFoods.add(foodDto);
			updateStatus = updateFoodQuantity(updatedFoods, updateType);
		}
		return updateStatus;
	}

	private void updatePaymentDetails(FoodDto food, FoodOrder foodOrder2, String updateType) {
		double updatedTotalAmount;
		if (updateType.equalsIgnoreCase("ADD")) {
			updatedTotalAmount = foodOrder2.getTotalPrice() + (food.getQuantity() * food.getPrice());
		} else {
			updatedTotalAmount = foodOrder2.getTotalPrice() + (-1 * food.getQuantity() * food.getPrice());
		}
		foodOrder2.getPayment().setAmount(updatedTotalAmount + "");
		foodOrder2.setTotalPrice(updatedTotalAmount);
	}

	private boolean updateFoodQuantity(List<FoodDto> updatedFoods, String requestStatus)
			throws InsuffecientQuantityException {
		FoodDto foodDto = null;
		boolean status = true;
		for (FoodDto food : updatedFoods) {
			foodDto = util.getFoodById(food.getFoodId());
			if (foodDto != null && (requestStatus.equalsIgnoreCase("PLACE") || requestStatus.equalsIgnoreCase("ADD"))) {
				if ((food.getQuantity() * -1) > foodDto.getQuantity()) {
					throw new InsuffecientQuantityException("Insufficient Qty please check Qty");
				}
			}
			util.updateFoodQuantity(food);
			if (foodDto == null) {
				status = false;
			}

		}
		return status;
	}

	private FoodOrder checkAndUpdatePaymentForOrder(FoodOrder foodOrder, FoodOrder foodOrder2, boolean updateStatus,
			PaymentDetail paymentDetail) throws PaymentFailedException {
		if (updateStatus) {

			if (foodOrder.getPayment() != null && !foodOrder.getPayment().getPaymentStatus().equalsIgnoreCase("PAID")) {
				throw new PaymentFailedException("Payment Failed");
			}
			paymentDetail.setOrder(foodOrder);

			double totalPrice = 0;
			List<FoodDto> foodList = foodOrder.getFoodsOrdered();
			for (FoodDto food : foodList) {
				food.setQuantity(food.getQuantity() * (-1));
				totalPrice += (food.getQuantity() * food.getPrice());
				food.setOrder(foodOrder);
			}
			foodOrder.setTotalPrice(totalPrice);
			foodOrder.setFoodsOrdered(foodList);
		}
		if (paymentDetail != null) {
			foodOrder.setOrderStatus("ACCEPTED");
			foodOrder2 = foodRepository.save(foodOrder);
		}
		return foodOrder2;
	}

}
