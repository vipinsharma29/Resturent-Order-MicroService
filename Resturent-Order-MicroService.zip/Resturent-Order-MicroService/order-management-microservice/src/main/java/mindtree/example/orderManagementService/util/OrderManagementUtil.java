package mindtree.example.orderManagementService.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import mindtree.example.orderManagementService.model.FoodDto;

@Service
public class OrderManagementUtil {

	@Autowired
	RestTemplate restTemplate;

	public FoodDto getFoodById(int foodId) {
		FoodDto food = restTemplate.getForObject("http://localhost:8081/api/foods/" + foodId, FoodDto.class);
		return food;
	}

	public FoodDto updateFoodQuantity(FoodDto food) {
		HttpEntity<FoodDto> request = new HttpEntity<>(food);
		ResponseEntity<FoodDto> response = restTemplate.exchange("http://localhost:8081/api/foods", HttpMethod.POST,
				request, FoodDto.class);
		return response.getBody();
	}
}
