package mindtree.example.orderManagementService.exception.service.custom;

import mindtree.example.orderManagementService.exception.service.ManageOrderServiceException;

public class NoOrderExistException extends ManageOrderServiceException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NoOrderExistException() {
		super();
		
	}

	public NoOrderExistException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		
	}

	public NoOrderExistException(String message, Throwable cause) {
		super(message, cause);
		
	}

	public NoOrderExistException(String message) {
		super(message);
		
	}

	public NoOrderExistException(Throwable cause) {
		super(cause);
		
	}

	
}
