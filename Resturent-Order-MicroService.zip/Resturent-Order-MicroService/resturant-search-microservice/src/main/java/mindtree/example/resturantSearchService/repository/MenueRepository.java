package mindtree.example.resturantSearchService.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import mindtree.example.resturantSearchService.model.Menue;

@Repository
public interface MenueRepository extends JpaRepository<Menue, Integer> {

}
