package mindtree.example.resturantSearchService.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import mindtree.example.resturantSearchService.dto.FoodDto;
import mindtree.example.resturantSearchService.dto.ResponseBody;
import mindtree.example.resturantSearchService.exception.ResturantSearchServiceAppException;
import mindtree.example.resturantSearchService.service.ResturantSearchService;

@RequestMapping("/api/resturants")
@RestController
public class ResturantServiceController {

	@Autowired
	ResturantSearchService searchService;

	@GetMapping("/name/{name}")
	public ResponseEntity<?> getResturantByName(@PathVariable String name) throws ResturantSearchServiceAppException {
		return new ResponseEntity<ResponseBody<FoodDto>>(
				new ResponseBody<FoodDto>(null, searchService.findByResturantName(name)), HttpStatus.OK);
	}

	@GetMapping("/city/{city}")
	public ResponseEntity<?> getResturantByCitye(@PathVariable String city)
			throws ResturantSearchServiceAppException {
		return new ResponseEntity<ResponseBody<FoodDto>>(
				new ResponseBody<FoodDto>(null, searchService.findByCity(city)), HttpStatus.OK);

	}

	@GetMapping("/budget/{budget}")
	public ResponseEntity<?> getResturantsByBudget(@PathVariable double budget)
			throws ResturantSearchServiceAppException {
		return new ResponseEntity<ResponseBody<FoodDto>>(
				new ResponseBody<FoodDto>(null, searchService.findByBudgetPerPerson(budget)), HttpStatus.OK);

	}
}
