package mindtree.example.resturantSearchService.service;

import java.util.List;

import org.springframework.stereotype.Service;

import mindtree.example.resturantSearchService.exception.service.ResturantSearchServiceException;
import mindtree.example.resturantSearchService.model.Resturant;

@Service
public interface ResturantSearchService {

	List<Resturant> findByResturantName(String name) throws ResturantSearchServiceException;

	List<Resturant> findByCity(String city) throws ResturantSearchServiceException;

	List<Resturant> findByBudgetPerPerson(double budget) throws ResturantSearchServiceException;
}
