package mindtree.example.resturantSearchService.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "resturant")
@Getter
@Setter
public class Resturant {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int resturantId;

	@OneToOne
	private Menue menue;

	private String resturantName;

	private String city;

	private double budget;

}
