package mindtree.example.resturantSearchService.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import mindtree.example.resturantSearchService.dto.FoodDto;
import mindtree.example.resturantSearchService.model.Food;
import mindtree.example.resturantSearchService.repository.FoodRepository;
import mindtree.example.resturantSearchService.service.FoodService;

@Service
public class FoodServiceImpl implements FoodService {

	@Autowired
	private FoodRepository foodRepository;

	@Override
	public FoodDto getFoodById(int foodId) {
		FoodDto foodDto = null;
		Food food = foodRepository.findById(foodId).orElse(null);
		if (food != null) {
			foodDto = new FoodDto();
			foodDto.setFoodId(foodId);
			foodDto.setQuantity(food.getQuantity());
			foodDto.setPrice(Double.parseDouble(food.getPrice()));
		}
		return foodDto;
	}

	@Override
	public FoodDto updateFoodQuantityById(int id, int quantity) {
		FoodDto foodDto = null;
		Food food = foodRepository.findById(id).orElse(null);
		if (food != null) {
			food.setQuantity(food.getQuantity() + quantity);
			food = foodRepository.save(food);
			foodDto = new FoodDto();
			foodDto.setFoodId(id);
			foodDto.setQuantity(quantity);
		}
		return foodDto;
	}

}
