package mindtree.example.resturantSearchService.service.impl;

import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import mindtree.example.resturantSearchService.model.Food;
import mindtree.example.resturantSearchService.repository.FoodRepository;
import mindtree.example.resturantSearchService.service.FoodService;

@ExtendWith(SpringExtension.class)
class FoodServiceImplTest {

	@TestConfiguration
	static class TestConfig {
		@Bean
		public FoodService foodService() {
			return new FoodServiceImpl();
		}
	}

	@Autowired
	private FoodService foodService;

	@MockBean
	private FoodRepository foodRepository;

	@Test
	public void getFoodByIdTest() {
		Food food = new Food();
		food.setFoodId(1);
		food.setPrice("250");
		food.setQuantity(20);
		when(foodRepository.findById(food.getFoodId())).thenReturn(Optional.of(food));
		foodService.getFoodById(food.getFoodId());
	}

	@Test
	public void updateFoodById() {
		Food food = new Food();
		food.setFoodId(1);
		food.setPrice("250");
		food.setQuantity(20);
		when(foodRepository.findById(food.getFoodId())).thenReturn(Optional.of(food));
		when(foodRepository.save(food)).thenReturn(food);
		foodService.updateFoodQuantityById(food.getFoodId(), food.getQuantity());
	}
}
